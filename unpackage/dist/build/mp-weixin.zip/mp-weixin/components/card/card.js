(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/card/card"],{"1adb":function(t,e,a){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n={props:{bodyStyle:String,headTitle:String,bodyCover:String,showhead:{type:Boolean,default:!0},headBorderBottom:{type:Boolean,default:!0},headTitleWeight:{type:Boolean,default:!0},bodyPadding:{type:Boolean,default:!1},cardStyle:{type:String,default:""}},computed:{getHeadClass:function(){var t=this.headBorderBottom?"border-bottom":"";return"".concat(t)},getBodyClass:function(){var t=this.bodyPadding?"p-2":"";return"".concat(t)}}};e.default=n},"1c4a":function(t,e,a){"use strict";a.r(e);var n=a("1adb"),o=a.n(n);for(var r in n)"default"!==r&&function(t){a.d(e,t,(function(){return n[t]}))}(r);e["default"]=o.a},"207a":function(t,e,a){"use strict";var n;a.d(e,"b",(function(){return o})),a.d(e,"c",(function(){return r})),a.d(e,"a",(function(){return n}));var o=function(){var t=this,e=t.$createElement;t._self._c},r=[]},a500:function(t,e,a){"use strict";var n=a("ea17"),o=a.n(n);o.a},bc44:function(t,e,a){"use strict";a.r(e);var n=a("207a"),o=a("1c4a");for(var r in o)"default"!==r&&function(t){a.d(e,t,(function(){return o[t]}))}(r);a("a500");var u,d=a("f0c5"),c=Object(d["a"])(o["default"],n["b"],n["c"],!1,null,"26b18274",null,!1,n["a"],u);e["default"]=c.exports},ea17:function(t,e,a){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/card/card-create-component',
    {
        'components/card/card-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("bc44"))
        })
    },
    [['components/card/card-create-component']]
]);
