(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["uview-ui/components/u-gap/u-gap"],{"3be9":function(t,e,n){"use strict";n.r(e);var r=n("b028"),a=n("752c");for(var u in a)"default"!==u&&function(t){n.d(e,t,(function(){return a[t]}))}(u);n("eeea");var o,i=n("f0c5"),c=Object(i["a"])(a["default"],r["b"],r["c"],!1,null,"64d82f34",null,!1,r["a"],o);e["default"]=c.exports},"576f":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:"u-gap",props:{bgColor:{type:String,default:"transparent "},height:{type:[String,Number],default:30},marginTop:{type:[String,Number],default:0},marginBottom:{type:[String,Number],default:0}},computed:{gapStyle:function(){return{backgroundColor:this.bgColor,height:this.height+"rpx",marginTop:this.marginTop+"rpx",marginBottom:this.marginBottom+"rpx"}}}};e.default=r},"752c":function(t,e,n){"use strict";n.r(e);var r=n("576f"),a=n.n(r);for(var u in r)"default"!==u&&function(t){n.d(e,t,(function(){return r[t]}))}(u);e["default"]=a.a},"949b":function(t,e,n){},b028:function(t,e,n){"use strict";var r;n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return r}));var a=function(){var t=this,e=t.$createElement,n=(t._self._c,t.__get_style([t.gapStyle]));t.$mp.data=Object.assign({},{$root:{s0:n}})},u=[]},eeea:function(t,e,n){"use strict";var r=n("949b"),a=n.n(r);a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'uview-ui/components/u-gap/u-gap-create-component',
    {
        'uview-ui/components/u-gap/u-gap-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("3be9"))
        })
    },
    [['uview-ui/components/u-gap/u-gap-create-component']]
]);
