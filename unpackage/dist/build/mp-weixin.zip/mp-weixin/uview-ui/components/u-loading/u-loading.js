(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["uview-ui/components/u-loading/u-loading"],{"62e0":function(e,t,n){},"6bc9":function(e,t,n){"use strict";n.r(t);var c=n("f27b"),r=n("aeca");for(var o in r)"default"!==o&&function(e){n.d(t,e,(function(){return r[e]}))}(o);n("9964");var u,i=n("f0c5"),a=Object(i["a"])(r["default"],c["b"],c["c"],!1,null,"631ca2f1",null,!1,c["a"],u);t["default"]=a.exports},9964:function(e,t,n){"use strict";var c=n("62e0"),r=n.n(c);r.a},aeca:function(e,t,n){"use strict";n.r(t);var c=n("e9e0"),r=n.n(c);for(var o in c)"default"!==o&&function(e){n.d(t,e,(function(){return c[e]}))}(o);t["default"]=r.a},e9e0:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var c={name:"u-loading",props:{mode:{type:String,default:"circle"},color:{type:String,default:"#c7c7c7"},size:{type:[String,Number],default:"34"},show:{type:Boolean,default:!0}},computed:{cricleStyle:function(){var e={};return e.width=this.size+"rpx",e.height=this.size+"rpx","circle"==this.mode&&(e.borderColor="#e4e4e4 #e4e4e4 #e4e4e4 ".concat(this.color?this.color:"#c7c7c7")),e}}};t.default=c},f27b:function(e,t,n){"use strict";var c;n.d(t,"b",(function(){return r})),n.d(t,"c",(function(){return o})),n.d(t,"a",(function(){return c}));var r=function(){var e=this,t=e.$createElement,n=(e._self._c,e.show?e.__get_style([e.cricleStyle]):null);e.$mp.data=Object.assign({},{$root:{s0:n}})},o=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'uview-ui/components/u-loading/u-loading-create-component',
    {
        'uview-ui/components/u-loading/u-loading-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("6bc9"))
        })
    },
    [['uview-ui/components/u-loading/u-loading-create-component']]
]);
